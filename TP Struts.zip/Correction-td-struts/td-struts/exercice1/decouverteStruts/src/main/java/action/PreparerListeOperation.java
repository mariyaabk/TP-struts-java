package action;

import com.opensymphony.xwork2.ActionSupport;

import java.util.Arrays;
import java.util.Collection;

public class PreparerListeOperation extends ActionSupport {

    public Collection<String> getOperations() {
        Collection<String> resultat = Arrays.asList("Division", "Somme", "Soustraction", "Multiplication");
        return resultat;
    }


}