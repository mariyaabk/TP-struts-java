package action;

import com.opensymphony.xwork2.ActionSupport;

import java.util.Arrays;
import java.util.Collection;


public class CalculStatique extends ActionSupport {

    private double operande1;
    private double operande2;
    private double res;
    private String typeOperation = "";



    public Collection<String> getOperations() {
        Collection<String> resultat = Arrays.asList("Division", "Somme", "Soustraction", "Multiplication");
        return resultat;
    }

    public String getTypeOperation() {
        return typeOperation;
    }

    public String setTypeOperation(String typeOperation) {
        return this.typeOperation = typeOperation;
    }


    public double getRes() {
        return res;
    }

    public double getOperande1() {
        return operande1;
    }

    public void setOperande1(double operande1) {
        this.operande1 = operande1;
    }

    public double getOperande2() {
        return operande2;
    }

    public void setOperande2(double operande2) {
        this.operande2 = operande2;
    }

    public void setRes(double res) {
        this.res = res;
    }

    @Override
    public String execute() throws Exception {
        res = 0d;
        switch (typeOperation) {
            case "Division": {
                if (getOperande2()==0) {
                    addFieldError("operande2","Pour une division, l''opérande 2 doit être différente de 0 !!");
                    return INPUT;
                }
                res= getOperande1()/getOperande2();
                break;
            }

            case "Somme": {
                res= getOperande1()+getOperande2();
                break;
            }

            case "Soustraction": {
                res= getOperande1()-getOperande2();
                break;
            }

            case "Multiplication": {
                res= getOperande1()*getOperande2();
                break;
            }
        }
        return SUCCESS;
    }




}