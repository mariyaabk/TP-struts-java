package action;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.inject.Inject;
import modele.CalculatriceDynamiqueDuFutur;
import modele.CalculatriceDynamiqueDuFuturImpl;
import modele.Etudiant;
import modele.FacadeModele;
import org.apache.struts2.interceptor.ApplicationAware;
import org.apache.struts2.interceptor.SessionAware;

import java.util.Collection;
import java.util.Map;

public class PreparerListeEtudiant extends ActionSupport implements SessionAware {
    private FacadeModele facadeModele;

    private Map<String,Object> variablesSessions;
    public Collection<Etudiant> getListeEtudiants() {
        return facadeModele.getEtudiants();
    }

    @Inject("facadeGestionEtudiant")
    public void setFacadeGestionEtudiant(FacadeModele facadeGestionEtudiant){
        this.facadeModele = facadeGestionEtudiant;
    }


    @Override
    public void setSession(Map<String, Object> map) {
        variablesSessions = map;
    }
}
