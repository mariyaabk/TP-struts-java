package action;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.inject.Inject;
import modele.CalculatriceDynamiqueDuFutur;
import modele.CalculatriceDynamiqueDuFuturImpl;
import org.apache.struts2.interceptor.ApplicationAware;

import java.util.Collection;
import java.util.Map;


public class CalculDynamique extends ActionSupport {
    private int operande1;
    private int operande2;
    private double res;
    private String typeOperation = "";
    private CalculatriceDynamiqueDuFutur calculatriceDynamiqueDuFutur;


    @Inject("facadeCalculatrice")
    public void setFacadeCalculatrice(CalculatriceDynamiqueDuFutur calculatriceDynamiqueDuFutur) {
        this.calculatriceDynamiqueDuFutur = calculatriceDynamiqueDuFutur;
    }




    public Collection<String> getOperations() {
        return calculatriceDynamiqueDuFutur.getOperations();
    }

    public String getTypeOperation() {
        return typeOperation;
    }

    public String setTypeOperation(String typeOperation) {
        return this.typeOperation = typeOperation;
    }


    public double getRes() {
        return res;
    }

    public int getOperande1() {
        return operande1;
    }

    public void setOperande1(int operande1) {
        this.operande1 = operande1;
    }

    public int getOperande2() {
        return operande2;
    }

    public void setOperande2(int operande2) {
        this.operande2 = operande2;
    }

    public void setRes(double res) {
        this.res = res;
    }
    public long getCompteur(){
        return calculatriceDynamiqueDuFutur.getValeurCompteur();
    }

    @Override
    public String execute() throws Exception {
        setRes(calculatriceDynamiqueDuFutur.doCalcul(getTypeOperation(), getOperande1(), getOperande2()));
        return SUCCESS;
    }


    @Override
    public void validate(){
        if ("Division".equals(typeOperation)) {
            if (getOperande2()==0)
                addFieldError("operande2","Division par zero impossible !!");
        }

    }


}