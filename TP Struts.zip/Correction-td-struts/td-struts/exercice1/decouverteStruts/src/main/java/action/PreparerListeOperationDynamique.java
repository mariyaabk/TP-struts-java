package action;

import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.inject.Inject;
import modele.CalculatriceDynamiqueDuFutur;
import modele.CalculatriceDynamiqueDuFuturImpl;
import org.apache.struts2.interceptor.ApplicationAware;

import java.util.Arrays;
import java.util.Collection;
import java.util.Map;


public class PreparerListeOperationDynamique extends ActionSupport {
    private int operande1;
    private int operande2;
    private double res;
    private String typeOperation = "";
    private CalculatriceDynamiqueDuFutur calculatriceDynamiqueDuFutur;


    @Inject("facadeCalculatrice")
    public void setFacadeCalculatrice(CalculatriceDynamiqueDuFutur calculatriceDynamiqueDuFutur) {
        this.calculatriceDynamiqueDuFutur = calculatriceDynamiqueDuFutur;
    }


    public Collection<String> getOperations() {
        return calculatriceDynamiqueDuFutur.getOperations();
    }


}