package action;

import com.opensymphony.xwork2.ActionSupport;

public class Saisie extends ActionSupport {
    private String pseudo;
    private String password;

    public void setPseudo(String pseudo) {
        this.pseudo = pseudo;
    }

    public String getPseudo() {
        return pseudo;
    }

    public void setPassword(String password) {

        this.password = password;
    }

    public String getPassword() {
        return password;
    }

    @Override
    public String execute() throws Exception {
        if(getPseudo() == null || getPassword() == null){
            if (getPassword() == null)
                addFieldError("password", "Il faut renseigner le password");


            if (getPseudo() == null)
                addFieldError("pseudo", "Il faut renseigner le pseudo");

            return INPUT;
        }

        else if(getPassword().length()<3 || getPassword().length()<3){

            if (getPassword().length() < 3)
                addFieldError("password", "password trop court");


            if (getPseudo().length() < 3)
                addFieldError("pseudo", "pseudo trop court");

            return INPUT;
    }
        else
            return SUCCESS;
    }
}
