package facade.exceptions;

public class UtilisateurDejaConnecteException extends Exception {
}
